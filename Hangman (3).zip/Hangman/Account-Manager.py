from ast import literal_eval
from flask import Flask, request, jsonify

api = Flask(__name__)

def checkArguments(arguments, received):
    missingArguments = []
    for argument in arguments:
        if argument not in received:
            missingArguments.append(argument)
    if len(missingArguments) > 0:
        return [False, missingArguments]
    return [True]

def retrieveAccount(username):
    return jsonify(literal_eval(open(f'{username}.json', 'r').read()))

def validateAccount(username):
    try:
        open(f'{username}.json', 'r')
    except FileNotFoundError:
        return False
    return True

def createAccount(username):
    return username

@api.route('/accountInformation', methods=['GET'])
def getAccountInformation():
    argumentCheck = checkArguments(['username', 'password'], request.args)
    if not argumentCheck[0]:
        return jsonify({'error': 'missing arguments', 'data': f'{", ".join(argumentCheck[1])}'})
    else:
        if validateAccount(request.args.get('username')):
            return retrieveAccount(request.args.get('username'))
        else:
            return jsonify({'error': 'user does not exist'})

@api.route('/accountManager/add', methods=['GET', 'POST'])
def addAccountInformation():
    argumentCheck = checkArguments(['username', 'password'], request.args)
    if not argumentCheck[0]:
        return jsonify({'error': 'missing arguments', 'data': f'{", ".join(argumentCheck[1])}'})
    else:
        if not validateAccount(request.args.get('username')):
            return createAccount(request.args.get('username'))
        else:
            return jsonify({'error': 'user already exists'})


if __name__ == '__main__':
    api.run('127.0.0.1', 80, debug=True)