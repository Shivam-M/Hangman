from tkinter import *
from threading import Thread


class Example:
    def __init__(self):

        self.BACKGROUND = '#141414'
        self.FOREGROUND = '#FFFFFF'
        self.Y = 1.05
        self.Delay = 1
        self.X = -1.00
        self.Delay2 = 1

        self.Window = Tk()
        self.Window.geometry('800x300')
        self.Window.configure(bg=self.BACKGROUND)

        self.FR_BLANK = Frame(self.Window, bg=self.FOREGROUND)
        self.FR_FILL = Frame(self.Window, bg=self.BACKGROUND)

        self.Window.bind('<Button-1>', lambda event: self.animate())

        self.Window.mainloop()

    def animate(self):
        print('animating')
        Thread(target=self.move).start()

    def move(self):
        self.Y -= 0.06
        self.Delay += 1
        print(self.Y)
        self.Window.after(self.Delay, lambda: self.FR_BLANK.place(relx=.0, rely=self.Y, width=800, height=300))
        if self.Y > 0:
            self.Window.after(self.Delay, lambda: self.move())
        else:
            self.Window.after(self.Delay, lambda: self.move2())

    def move2(self):
        self.X += 0.06
        self.Delay2 += 1
        self.Window.after(self.Delay2, lambda: self.FR_FILL.place(relx=self.X, rely=.0, width=800, height=300))
        print(self.X)
        if -0.08 < self.X < -0.01:
            self.Window.after(self.Delay2, lambda: self.FR_FILL.place(relx=0, rely=.0, width=800, height=300))
        if self.X < -0.02:
            self.Window.after(self.Delay2, lambda: self.move2())


Example()
