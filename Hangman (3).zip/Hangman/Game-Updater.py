from zipfile import ZipFile
from configparser import ConfigParser
from urllib.request import urlretrieve # Switch to requests module soon.
import os, shutil


class Updater:
    def __init__(self, dir):
        self.Program_Name = None
        self.Program_Url = None
        self.Program_Version_File = None
        self.Program_Ignored_Files = None
        self.Update_Directory = dir
        self.Version_URL = None
        self.Configuration = ConfigParser()
        try:
            with open('update-config.ini', 'r'):
                self.Configuration.read('update-config.ini')
        except FileNotFoundError:
            print('No configuration file found - initializing first time setup.')
            self.setup()
            return
        self.Program_Name = self.Configuration['Settings']['Name']
        self.Program_Url = self.Configuration['Settings']['URL']
        self.Program_Version_File = self.Configuration['Settings']['Version']
        self.Program_Ignored_Files = self.Configuration['Settings']['Ignored']
        self.check()

    def setup(self):
        self.Program_Name = input('Please enter program name: ')
        self.Program_Url = input('Please enter the remote GitHub URL: ')
        self.Program_Version_File = input('Please enter the name of the version file: ')
        self.Program_Ignored_Files = input('Please enter any ignored files (separated by \',\' - leave blank for none): ')
        self.Configuration.read('update-config.ini')
        self.Configuration.add_section('Settings')
        self.Configuration.set('Settings', 'Name', self.Program_Name)
        self.Configuration.set('Settings', 'URL', self.Program_Url)
        self.Configuration.set('Settings', 'Version', self.Program_Version_File)
        self.Configuration.set('Settings', 'Ignored', self.Program_Ignored_Files)

        with open('update-config.ini', 'w') as Config:
            self.Configuration.write(Config)

    def check(self):
        print(os.getcwd())
        self.CURRENT_VERSION = float(open('version.txt', 'r').read())
        a = self.Program_Url.split('/')
        self.Version_URL = 'https://raw.githubusercontent.com/' + a[3] + '/' + a[4] + '/master/' + self.Program_Version_File
        urlretrieve(self.Version_URL, 'latest-version.txt')
        self.LATEST_VERSION = float(open('latest-version', 'r').read())
        os.remove('latest-version.txt')
        if self.LATEST_VERSION > self.CURRENT_VERSION:
            print('Update available')
        else:
            print('Up to date')


    def check2(self):
        Original_Dir = os.getcwd()
        print('Creating backup of original files in above directory...')
        os.chdir('..')
        shutil.make_archive('Backup', 'zip', self.Program_Name)
        os.chdir(Original_Dir)
        print(f'Backup created for folder \'{self.Program_Name}\'')
        for the_file in os.listdir(os.getcwd()):
            file_path = os.path.join(os.getcwd(), the_file)
            try:
                if os.path.isfile(file_path):
                    os.unlink(file_path)
                elif os.path.isdir(file_path):
                    try:
                        shutil.rmtree(file_path)
                    except:
                        pass
            except Exception as e:
                print(e)
        os.mkdir(self.Update_Directory)
        os.chdir(self.Update_Directory)
        urlretrieve(self.Program_Url + '/archive/master.zip', 'Latest.zip')
        Latest_Files = ZipFile('Latest.zip', 'r')
        Latest_Files.extractall('../')
        Latest_Files.close()
        os.chdir('..')
        source = os.path.join(os.getcwd() + f'\\{self.Program_Name}-master/')
        dest = os.getcwd()

        files = os.listdir(source)
        try:
            for f in files:
                shutil.move(source+f, dest)
        except Exception as e:
            print(e)

        print('Update completed')


if __name__ == '__main__':
    Test = Updater('Updater')