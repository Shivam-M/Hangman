import time
from threading import Thread
from tkinter import *
from Player import Player
from random import choice
from tools.Network2 import NetworkM


# TODO: Create network session early on
# TODO: Lobby system using: GameManager.py
# TODO: Player identification


class Test:
    def __init__(self, instance):

        self._VERSION = 0.78
        self.BACKGROUND = '#141414'
        self.FOREGROUND = '#FFFFFF'
        self.mainInstance = instance
        self.Window = self.mainInstance.Window

        self.Session = NetworkM('127.0.0.1', 6666, self)
        self.Session.run()

        self.Game = Frame(self.Window, bg=self.BACKGROUND)

        self.timerBar = Label(self.Game, text='_______________', font=('Arial', 12, 'bold'), bg='#141414', fg='#FFFFFF', bd=0, width=20, anchor='w')

        self.nameList = Text(self.Game, font=('MS PGothic', 12, 'bold'), bg='#141414', fg='#95a5a6', bd=0, width=15, height=8)
        self.scoreList = Text(self.Game, font=('MS PGothic', 12, 'bold'), bg='#141414', fg='#7f8c8d', bd=0, width=15, height=8)

        self.gameInformation = Label(self.Game, text=f'Go to the colour', fg=self.BACKGROUND, bg='#e74c3c', width=20, font=('MS PGothic', 12, 'bold'))

        self.gameCommand = Label(self.Game, text=f'Go to the colour', fg=self.BACKGROUND, bg=self.FOREGROUND, width=20, font=('MS PGothic', 12, 'bold'))

        self.gameColour = Label(self.Game, text=f'Green', fg=self.BACKGROUND, bg='#2ecc71', width=8, font=('MS PGothic', 12, 'bold'))

        self.gameBuild = Label(self.Game, bg=self.BACKGROUND, fg='#bdc3c7', font=('MS PGothic', 8, 'bold'), text=f'Development build: {self._VERSION}')
        self.gameBuild.place(relx=.05, rely=0)

        self.gameColours = ['Purple', 'Red', 'Blue', 'Yellow', 'Green']
        self.gamePhase = 'STILL'

        self.hostingMatch = True
        self.currentColour = 'Green'

        self.count = 1
        self.delay = 50
        self.matchCount = 0

        self.platformRanges = [[0.04, 0.14], [0.24, 0.34], [0.44, 0.54], [0.64, 0.74], [0.84, 0.94]]

        self.playersAlive = 10

        self.playerIndex = 2

        self.playerModels = []
        self.playerCount = 4
        self.playerColours = ['#e74c3c', '#3498db', '#f1c40f', '#2ecc71']
        self.playerPositions = [0.24, 0.44, 0.64, 0.84]

        self.platformModels = []
        self.platformColours = ['#9b59b6', '#e74c3c', '#3498db', '#f1c40f', '#2ecc71']
        self.platformPositions = [0.04, 0.24, 0.44, 0.64, 0.84]

        self.gameOver = False

        for x in range(self.playerCount):
            self.playerModels.append(Player(x, self, self.playerColours[x]))
            self.playerModels[x].draw(relx=self.playerPositions[x], rely=.8)

        for x in range(5):
            self.platformModels.append(Label(self.Game, text=' ', bg=self.platformColours[x], fg=self.platformColours[x], width=20, font='Arial 6 bold'))
            self.platformModels[x].place(relx=self.platformPositions[x], rely=.9)

        self.playerModels[self.playerIndex].controller()

        self.otherT = Thread(target=self.othread)

    def start(self):
        self.otherT.start()

    def standing(self, player):
        for range in self.platformRanges:
            if range[0] <= player[0] <= range[1]:
                return [True, self.gameColours[self.platformRanges.index(range)]]
        return [False]

    def place(self):
        for x in range(self.playerCount):
            self.playerModels.append(Player(x, self, self.playerColours[x]))
            self.playerModels[x].draw(relx=self.playerPositions[x], rely=.8)

    def configure(self, colour):
        self.currentColour = colour
        self.gameColour.config(text=self.currentColour, bg=self.platformColours[self.gameColours.index(self.currentColour)])
        # self.Game.after(2000, lambda: self.remove(self.gameColours.index(self.currentColour)))

    def colour(self):
        self.currentColour = choice(self.gameColours)
        self.gameColour.config(text=self.currentColour, bg=self.platformColours[self.gameColours.index(self.currentColour)])
        self.Session.send(str({'data-type': 'colour-name', 'colour': self.currentColour}))

    def run(self, position):
        self.Game.place(relx=.0, rely=.1, width=850, height=250)
        self.hostingMatch = position
        # self.countdown()
        if self.hostingMatch:
            self.Session.send(str({'data-type': 'game-start'}))
            self.Game.after(1000, lambda: self.colour())

    def timer(self):
        self.delay += 50
        self.count += 1
        self.Window.after(self.delay, lambda: self.timerBar.config(text='_' * self.count))
        if self.count != 25:
            self.timer()

    def build(self):
        for x in range(5):
            self.platformModels.append(Label(self.Game, text=' ', bg=self.platformColours[x], fg=self.platformColours[x], width=20, font='Arial 6 bold'))
            self.platformModels[x].place(relx=self.platformPositions[x], rely=.9)

    def remove(self, index):
        for Platform in self.platformModels:
            if self.platformModels.index(Platform) != index:
                Platform.place_forget()

    def othread(self):
        self.countdown()
        time.sleep(3)
        cd = 3
        while not self.gameOver:
            time.sleep(cd)
            self.gamePhase = 'FALLING'
            self.remove(self.gameColours.index(self.currentColour))
            time.sleep(2)
            self.colour()
            time.sleep(0.125)
            self.build()
            self.gamePhase = 'STILL'
            cd -= 0.2
            if cd < 0.5:
                cd = 0.55
            self.matchCount += 1
            if self.playersAlive <= 1:
                self.gameOver = True
                self.scores()
            self.playersAlive -= 1

    def countdown(self):
        self.gameInformation.place(relx=.37, rely=.2)
        self.gameInformation.config(bg=self.FOREGROUND, text='Game is starting in 3')
        self.Window.after(1000, lambda: (self.gameInformation.config(text='Game is starting in 2')))
        self.Window.after(2000, lambda: self.gameInformation.config(text='Game is starting in 1'))
        self.Window.after(3000, lambda: (self.gameCommand.place(relx=.32, rely=.2), self.gameColour.place(relx=.57, rely=.2), self.gameInformation.place_forget()))
        # self.Window.after(4750, lambda: (self.gameColour.place_forget(), self.gameCommand.place_forget(), self.scores()))

    def scores(self):
        for GamePlatform in self.platformModels:
            GamePlatform.place_forget()
        for GamePlayer in self.playerModels:
            GamePlayer.place_forget()
        self.gameCommand.place_forget()
        self.gameColour.place_forget()

        self.nameList.place(relx=.37, rely=.35)
        self.Game.after(100, lambda: self.nameList.insert(INSERT, 'Player 1\n\n'))
        self.Game.after(200, lambda: self.nameList.insert(INSERT, 'Player 2\n\n'))
        self.Game.after(300, lambda: self.nameList.insert(INSERT, 'Player 3\n\n'))
        self.Game.after(400, lambda: self.nameList.insert(INSERT, 'Player 4'))

        self.scoreList.place(relx=.57, rely=.35)
        self.Game.after(100, lambda: self.scoreList.insert(INSERT, '6000\n\n'))
        self.Game.after(200, lambda: self.scoreList.insert(INSERT, '4000\n\n'))
        self.Game.after(300, lambda: self.scoreList.insert(INSERT, '3000\n\n'))
        self.Game.after(400, lambda: self.scoreList.insert(INSERT, '1000\n\n'))

        self.gameInformation.place(relx=.37, rely=.2)
        self.gameInformation.config(text='GAME OVER')


if __name__ == '__main__':
    Test(__name__)
