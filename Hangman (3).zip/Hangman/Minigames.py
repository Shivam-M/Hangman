from tkinter import *
from Game import Test


class Games:
    def __init__(self):
        self.BACKGROUND = '#141414'
        self.FOREGROUND = '#FFFFFF'
        self.RESOLUTION = '850x325'
        self.LOBBY_TOKEN = ''

        self.Window = Tk()
        self.Window.config(bg=self.BACKGROUND)
        self.Window.geometry(f'{self.RESOLUTION}+400+200')
        self.Window.title(f'BUILD_ALPHA ({self.RESOLUTION})')

        self.Lab = Label(self.Window, text='TEST MODE - ALPHA', font=('Courier New', 22, 'bold'), bg='#141414', fg='#FFFFFF').place(relx=.6, rely=.8)

        self.LabelCode = Label(self.Window, text='LOBBY CODE', font=('Courier New', 22, 'bold'), bg='#141414', fg='#FFFFFF').place(relx=.05, rely=.35)

        self.EntryCode = Entry(self.Window, width=20, font=('Courier New', 26, 'bold'), bg='#141414', fg='#FFFFFF', insertbackground='#FFFFFF', bd=0)
        self.EntryCode.place(relx=.05, rely=.45)
        self.EntryCode.focus()

        self.Games = ['Game1', 'Game2']
        self.Games2 = [Test(self)]

        self.hostM = Button(self.Window, text='Host match', font=('MS PGothic', 12, 'bold'), bg='#141414', fg='#FFFFFF', bd=0, command=lambda: (self.joinM.place_forget(), self.hostM.place_forget(), self.Games2[0].run(True)))
        self.joinM = Button(self.Window, text='Join match', font=('MS PGothic', 12, 'bold'), bg='#141414', fg='#FFFFFF', bd=0, command=lambda: (self.joinM.place_forget(), self.hostM.place_forget(), self.Games2[0].run(False)))
        self.hostM.place(relx=.05, rely=.85)
        self.joinM.place(relx=.2, rely=.85)

        # self.Games2[0].run(go)

        self.Window.mainloop()


if __name__ == '__main__':
    Games()
