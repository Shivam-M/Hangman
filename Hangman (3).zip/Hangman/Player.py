from tkinter import *
from threading import Thread
from time import sleep


class Player:
    def __init__(self, identifier, instance, colour):
        self.Identifier = identifier
        self.playerColour = colour
        self.gameInstance = instance
        self.mainInstance = self.gameInstance.mainInstance
        self.Game = self.gameInstance.Game

        self.playerVisible = True
        self.playerVelocity = [0.000, 0.000]
        self.playerLocation = [0, 0]
        self.playerController = False

        self.movingRight = False
        self.movingLeft = False

        self.Player = Label(self.Game, text='▀', bg='#141414', fg=self.playerColour, font='Arial 22 bold')

        self.movementThread = Thread(target=self.movement)

    def draw(self, relx=0, rely=0):
        self.Player.place(relx=relx, rely=rely)
        self.playerLocation = [relx, rely]
        self.movementThread.start()

    def place(self, relx=0.0, rely=1.0):
        self.Player.place(relx=relx, rely=rely)
        self.playerLocation = [relx, rely]

    def place_forget(self):
        self.playerVisible = False
        self.playerController = False
        self.Player.place_forget()

    def velocity(self, velocity):
        self.playerVelocity = velocity

    def movement(self):
        inRange = False
        while True:
            for range in self.gameInstance.platformRanges:
                if range[0] <= self.playerLocation[0] <= range[1]:
                    inRange = True
                    break
            if self.gameInstance.gamePhase == 'FALLING':
                if self.gameInstance.standing(self.playerLocation)[0]:
                    if self.gameInstance.currentColour == self.gameInstance.standing(self.playerLocation)[1]:
                        print('Under correct colour!')
                    else:
                        self.hide()
                else:
                    self.hide()
            if not inRange:
                if self.playerLocation[1] >= 0.82:
                    self.hide()
            if self.playerVisible:
                if self.playerVelocity[1] > 0:
                    if self.playerLocation[1] < 0.80:
                        self.playerLocation = [self.playerLocation[0], self.playerLocation[1] + self.playerVelocity[1]]
                else:
                    self.playerLocation = [self.playerLocation[0], self.playerLocation[1] + self.playerVelocity[1]]
                self.playerLocation = [self.playerLocation[0] + self.playerVelocity[0], self.playerLocation[1]]
                self.place(self.playerLocation[0], self.playerLocation[1])
                # self.playerLocation = [self.playerLocation[0] + self.playerVelocity[0], self.playerLocation[1] + self.playerVelocity[1]]
            else:
                self.hide()
            sleep(0.005)

    def controller(self):
        self.playerController = True
        self.mainInstance.Window.bind('<Right>', self.controls)
        self.mainInstance.Window.bind('<Left>', self.controls)
        self.mainInstance.Window.bind('<Up>', self.controls)
        self.mainInstance.Window.bind('<space>', self.controls)
        self.mainInstance.Window.bind('<KeyRelease-Right>', self.releaser)
        self.mainInstance.Window.bind('<KeyRelease-Left>', self.releaser)

    def releaser(self, event):
        if self.playerController:
            if event.keysym == 'Right':
                self.movingRight = False
                if not self.movingLeft:
                    self.velocity([0, self.playerVelocity[1]])
            elif event.keysym == 'Left':
                self.movingLeft = False
                if not self.movingRight:
                    self.velocity([0, self.playerVelocity[1]])

    def controls(self, event):
        if self.playerController:
            if event.keysym == 'Right':
                self.velocity([0.0025, self.playerVelocity[1]])
                self.movingRight = True
            elif event.keysym == 'Left':
                self.velocity([-0.0025, self.playerVelocity[1]])
                self.movingLeft = True
            elif event.keysym == 'space':
                self.velocity([0.000, 0.000])
            elif event.keysym == 'Up':
                self.velocity([self.playerVelocity[0], -0.005])
                self.Game.after(200, lambda: self.velocity([self.playerVelocity[0], 0.005]))

    def hide(self):
        self.playerVisible = False
        self.Player.place_forget()
