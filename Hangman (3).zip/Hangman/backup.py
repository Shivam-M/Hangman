from tkinter import *


class Test:
    def __init__(self, instance):
        self.BACKGROUND = '#141414'
        self.FOREGROUND = '#FFFFFF'
        self.mainInstance = instance
        self.Window = self.mainInstance.Window

        self.Game = Frame(self.Window, bg=self.BACKGROUND)

        self.nameList = Text(self.Game, font=('MS PGothic', 12, 'bold'), bg='#141414', fg='#95a5a6', bd=0, width=15, height=8)
        self.scoreList = Text(self.Game, font=('MS PGothic', 12, 'bold'), bg='#141414', fg='#7f8c8d', bd=0, width=15, height=8)

        self.gameInformation = Label(self.Game, text=f'Go to the colour', fg=self.BACKGROUND, bg='#e74c3c', width=20, font=('MS PGothic', 12, 'bold'))

        self.gameCommand = Label(self.Game, text=f'Go to the colour', fg=self.BACKGROUND, bg=self.FOREGROUND, width=20, font=('MS PGothic', 12, 'bold'))

        self.gameColour = Label(self.Game, text=f'Green', fg=self.BACKGROUND, bg='#2ecc71', width=8, font=('MS PGothic', 12, 'bold'))

        self.playerModels = []
        self.playerCount = 4
        self.playerColours = ['#e74c3c', '#3498db', '#f1c40f', '#2ecc71']
        self.playerPositions = [0.24, 0.44, 0.64, 0.84]

        self.platformModels = []
        self.platformColours = ['#9b59b6', '#e74c3c', '#3498db', '#f1c40f', '#2ecc71']
        self.platformPositions = [0.04, 0.24, 0.44, 0.64, 0.84]

        for x in range(self.playerCount):
            self.playerModels.append(Label(self.Game, text='▀', bg=self.BACKGROUND, fg=self.playerColours[x], font='Arial 22 bold'))
            self.playerModels[x].place(relx=self.playerPositions[x], rely=.8)

        for x in range(5):
            self.platformModels.append(Label(self.Game, text=' ', bg=self.platformColours[x], fg=self.platformColours[x], width=20, font='Arial 6 bold'))
            self.platformModels[x].place(relx=self.platformPositions[x], rely=.9)

        # self.scores()

    def run(self):
        self.Game.place(relx=.0, rely=.1, width=850, height=250)
        self.countdown()

    def countdown(self):
        self.gameInformation.place(relx=.37, rely=.2)
        self.gameInformation.config(bg=self.FOREGROUND, text='Game is starting in 3')
        self.Window.after(1000, lambda: self.gameInformation.config(text='Game is starting in 2'))
        self.Window.after(2000, lambda: self.gameInformation.config(text='Game is starting in 1'))
        self.Window.after(3000, lambda: (self.gameCommand.place(relx=.32, rely=.2), self.gameColour.place(relx=.57, rely=.2), self.gameInformation.place_forget()))
        self.Window.after(4750, lambda: (self.gameColour.place_forget(), self.gameCommand.place_forget(), self.scores()))

    def scores(self):
        for Platform in self.platformModels:
            Platform.place_forget()
        for Player in self.playerModels:
            Player.place_forget()
        self.gameCommand.place_forget()
        self.gameColour.place_forget()

        self.nameList.place(relx=.37, rely=.35)
        self.nameList.insert(INSERT, 'Player 1\n\n')
        self.nameList.insert(INSERT, 'Player 2\n\n')
        self.nameList.insert(INSERT, 'Player 3\n\n')
        self.nameList.insert(INSERT, 'Player 4')

        self.scoreList.place(relx=.57, rely=.35)
        self.scoreList.insert(INSERT, '6000\n\n')
        self.scoreList.insert(INSERT, '4000\n\n')
        self.scoreList.insert(INSERT, '3000\n\n')
        self.scoreList.insert(INSERT, '1000')

        self.gameInformation.place(relx=.37, rely=.2)
        self.gameInformation.config(text='GAME OVER')

if __name__ == '__main__':
    Test(__name__)