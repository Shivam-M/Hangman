from tkinter import *


class Builder:
    def __init__(self):
        self.Window = Tk()
        self.Window.geometry('800x300')
        self.Window.config(bg='#141414')

        self.Moving = False
        self.Label_Title = Label(self.Window, text='Hello!', bg='#FFFFFF', fg='#141414')
        self.Label_Title.place(relx=.05, rely=.2)

        self.Window.bind('<Button-1>', lambda event: self.toggle())
        self.Window.bind('<ButtonRelease-1>', lambda event: self.toggle())
        self.Label_Title.bind('<Motion>', self.move)

        self.Window.mainloop()

    def toggle(self):
        self.Moving = not self.Moving

    def move(self, event):
        try:
            if self.Moving:
                x, y = self.Window.winfo_pointerxy()
                widget = self.Window.winfo_containing(x, y)
                widget.place(relx=event.x / 800, rely=event.y / 300)
                print(event.x / 800, event.x / 300)
        except AttributeError:
            pass

Builder()