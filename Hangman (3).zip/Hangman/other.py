import requests

newurl = input('New url: ')

requests.get(f'http://chat-sv.ddns.net:5000/change?url={newurl}')