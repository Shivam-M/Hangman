from flask import Flask, request
from werkzeug.utils import redirect

URL = 'http://blog.counter-strike.net'
app = Flask(__name__)

@app.route('/', methods=['GET'])
def home():
    global URL
    return redirect(URL)

@app.route('/change', methods=['GET', 'POST'])
def change():
    global URL
    URL = request.args.get('url')
    print('New URL is', URL)
    return URL

if __name__ == '__main__':
    app.run('0.0.0.0', 5000, debug=True)