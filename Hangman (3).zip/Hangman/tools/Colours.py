

class Colours:
    def __init__(self):
        self.PURPLE = '#9B59B6'
        self.DARK_PURPLE = '#8E44AD'
        self.LIGHT_BLUE = '#3498DB'
        self.BLUE = '#2980B9'
        self.DARK_BLUE = '#34495E'
        self.DEEP_BLUE = '#2C3E50'
        self.GREEN = '#2ECC71'
        self.SEA_GREEN = '#1ABC9C'
        self.DARK_SEA_GREEN = '#16A085'
        self.DARK_GREEN = '#27AE60'
        self.YELLOW = '#F1C40F'
        self.LIGHT_ORANGE = '#F39C12'
        self.ORANGE = '#E67E22'
        self.DARK_ORANGE = '#D35400'
        self.RED = '#E74C3C'
        self.DARK_RED = '#C0392B'
        self.SILVER = '#BDC3C7'
        self.LIGHT_GREY = '#95A5A6'
        self.GREY = '#7F8C8D'
        self.DARK_GREY = '#2F3542'
